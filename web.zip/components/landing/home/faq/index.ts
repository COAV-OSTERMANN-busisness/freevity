export { FAQ } from "./FAQ";
